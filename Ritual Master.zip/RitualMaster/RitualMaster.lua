-- Ritual Master = Rune of Chaos (etat de Harbinger) + Pact of Slaanesh (Ritual Nexus).
-- Tout fonctionne par evenements ; le seul calcul continu est la direction du pointer, et uniquement
-- quand un Nexus est actif et que le pointer est active.
RitualMaster = RitualMaster or {}
local R = RitualMaster

-- Fenetres
local STATE, STATE_ICON = "RMStateWindow", "RMStateWindowIcon"
local NEXUS, NEXUS_ICON = "RMNexusWindow", "RMNexusWindowIcon"
local CIRCLE, CIRCLE_ICON, SCALE = "RMCircleWindow", "RMCircleWindowIcon", "RMScaleWindow"

-- Harbinger
local HARBINGER_IDS = { [8550] = true, [1659] = true }
local CD_THRESHOLD = 3
local DEFAULT_SIZE = 64
local HARBINGER_TEX = {
    [66] = { DPS = "RM_ZealotDps",     HEAL = "RM_ZealotHeal" },
    [22] = { DPS = "RM_RunePriestDps", HEAL = "RM_RunePriestHeal" },
}

-- Nexus
local RUNE_PRIEST = 22
local NEXUS_BUFF = 6040
local NEXUS_BUFF_RP = 6039                   -- effet "Ritual Nexus" (Zealot) sur le joueur
local NEXUS_NAMES = { ["ritual nexus"] = true, ["runic conduit"] = true }   -- Zealot / Rune Priest (par nom)
local HALF = 32
local INTERVAL = 0.05

local COLORS = {
    base      = { 235,  70, 205 },   -- Zealot : magenta
    rpbase    = {  70, 237, 186 },   -- Rune Priest : vert turquoise clair, un peu plus vert
    superior  = {   0, 230, 255 },   -- Ritual of Superiority : cyan
    lunacy    = { 255, 235,  40 },   -- Ritual of Lunacy : jaune
    innerv    = { 255, 150,  30 },   -- Ritual of Innervation : orange
    fury      = { 255, 150,  30 },   -- Master Rune of Fury : orange
    stability = { 255, 235,  40 },   -- Master Rune of Stability : jaune
    adamant   = {  45, 115, 235 },   -- Master Rune of Adamant : bleu plus soutenu et plus fonce
    tacticZ   = { 255,  50,  50 },   -- Nexus en version DPS (Zealot) : rouge
    tacticRP  = { 255,  50,  50 },   -- Rune of Wrath and Ruin / hors de portee (Rune Priest) : rouge
}
local RITUAL_IDS = {
    [35592] = "superior", [35591] = "lunacy", [35590] = "innerv",
    [35588] = "fury",     [35587] = "stability", [35589] = "adamant",
}
local RITUAL_NAMES = {
    ["ritual of superiority"] = "superior", ["ritual of lunacy"] = "lunacy", ["ritual of innervation"] = "innerv",
    ["master rune of fury"] = "fury", ["master rune of stability"] = "stability", ["master rune of adamant"] = "adamant",
}
local TACTIC_IDS = { [8585] = true, [35593] = true, [32584] = true }
local TACTIC_NAMES = { ["waves of chaos"] = true, ["rune of wrath and ruin"] = true }

local DEFAULTS = { on = true, dps = true, heal = true, pointer = true, colors = true, symbol = true,
                   sizePointer = 0, sizeSymbol = 0, sizeDps = 0, sizeHeal = 0 }   -- tailles : 0 = 64 (images fournies)

local S                                   -- reglages (sauvegardes par personnage)
R.savedState = R.savedState or "HEAL"
R.state = "HEAL"                          -- apres une (re)connexion Harbinger est toujours inactif

local loadedOn, harbOn, nexusOn = false, false, false
local slot, drawnTex, stateShown
local active, attachedObj, acc = false, nil, 0
local baseKey, symKey, cirKey, tacticAtCreation = "base", nil, nil, false

local function say(text, icon) TextLogAddEntry("Chat", 0, towstring("<icon" .. (icon or 49) .. "> " .. text)) end

local function registerGroup(list, on)
    for _, e in ipairs(list) do
        if on then RegisterEventHandler(e[1], e[2]) else UnregisterEventHandler(e[1], e[2]) end
    end
end

local LOADED_EVENTS = {
    { SystemData.Events.ALL_MODULES_INITIALIZED, "RitualMaster.OnLoaded" },
    { SystemData.Events.LOADING_END,             "RitualMaster.OnLoaded" },
    { SystemData.Events.RELOAD_INTERFACE,        "RitualMaster.OnReload" },
}
local HARBINGER_EVENTS = {
    { SystemData.Events.PLAYER_ABILITY_TOGGLED,    "RitualMaster.OnToggled" },
    { SystemData.Events.PLAYER_COOLDOWN_TIMER_SET, "RitualMaster.OnCooldownSet" },
    { SystemData.Events.PLAYER_HOT_BAR_UPDATED,    "RitualMaster.FindSlot" },
}
local NEXUS_EVENTS = {
    { SystemData.Events.PLAYER_PET_UPDATED,     "RitualMaster.RefreshNexus" },
    { SystemData.Events.PLAYER_EFFECTS_UPDATED, "RitualMaster.OnEffects" },
}

-- =============================================================== Harbinger
function R.FindSlot()
    slot = nil
    for i = 0, 121 do
        local _, id = GetHotbarData(i)
        if HARBINGER_IDS[id] then slot = i return end
    end
end

local function getCooldown()
    if not slot then return 0 end
    local ok, cd = pcall(GetHotbarCooldown, slot)
    if ok then return tonumber(cd) or 0 end
    return 0
end

local function drawState()
    local tex = R.textures and R.textures[R.state]
    if not tex then return end
    local size = (R.state == "DPS") and S.sizeDps or S.sizeHeal
    if size <= 0 then size = DEFAULT_SIZE end
    local sig = tex .. size
    if drawnTex ~= sig then
        drawnTex = sig
        DynamicImageSetTexture(STATE_ICON, tex, 0, 0)
        DynamicImageSetTextureDimensions(STATE_ICON, size, size)
    end
    local show = S.on and ((R.state == "DPS" and S.dps) or (R.state == "HEAL" and S.heal)) or false
    if show ~= stateShown then
        stateShown = show
        WindowSetShowing(STATE, show)
    end
end

local function setState(state)
    R.state, R.savedState = state, state
    drawState()
end

function R.OnToggled(abilityId)
    if not HARBINGER_IDS[abilityId] then return end
    if not slot then R.FindSlot() end
    if getCooldown() > CD_THRESHOLD then setState("HEAL") else setState("DPS") end
end

function R.OnCooldownSet()
    if R.state == "DPS" and slot and getCooldown() > CD_THRESHOLD then setState("HEAL") end
end

local function harbingerLoaded()
    R.FindSlot()
    if getCooldown() > CD_THRESHOLD then R.state, R.savedState = "HEAL", "HEAL" end
    drawState()
end

-- =============================================================== Nexus
local function setColors(sym, cir)
    if not S.colors then sym, cir = baseKey, baseKey end
    if sym ~= symKey then
        symKey = sym
        local c = COLORS[sym]
        WindowSetTintColor(NEXUS_ICON, c[1], c[2], c[3])
    end
    if cir ~= cirKey then
        cirKey = cir
        local c = COLORS[cir]
        WindowSetTintColor(CIRCLE_ICON, c[1], c[2], c[3])
    end
end

-- Le Nexus a-t-il la tactique DPS equipee ? (lu une seule fois, a la creation du Nexus)
local function dpsTacticEquipped()
    local act = GetActiveTactics(GameData.AbilityType.TACTIC)
    if type(act) ~= "table" then return false end
    for _, id in pairs(act) do
        if TACTIC_IDS[id] then return true end
    end
    local tbl = GetAbilityTable(GameData.AbilityType.TACTIC)
    if tbl then
        for _, id in pairs(act) do
            local a = tbl[id]
            if a and TACTIC_NAMES[string.lower(tostring(a.name or ""))] then return true end
        end
    end
    return false
end

-- Couleurs d'apres les buffs du joueur.
--  * symbole (sur le Nexus) : seulement MON rituel ; sinon l'etat de MON Nexus (rouge = hors de portee ou version DPS)
--  * pointer (sur le joueur) : mon rituel, sinon celui d'un allie ; sinon rouge si aucun Nexus ne me soigne
-- (le Nexus ne soigne plus quand on est hors de portee : la phrase "recovering ... Health" disparait de l'effet)
local function currentKeys()
    local buffs = GetBuffs(GameData.BuffTargetType.SELF)
    local mineRitual, anyRitual, mineNexus, mineHeal, anyHeal
    if buffs then
        for _, b in pairs(buffs) do
            local name = string.lower(tostring(b.name or ""))
            local text = string.lower(tostring(b.effectText or ""))
            local key = RITUAL_IDS[b.abilityId] or RITUAL_NAMES[name]
            if key then
                anyRitual = anyRitual or key
                if b.castByPlayer then mineRitual = mineRitual or key end
            elseif b.abilityId == NEXUS_BUFF or b.abilityId == NEXUS_BUFF_RP or NEXUS_NAMES[name] or string.find(text, "maintaining r", 1, true) then
                local heal = string.find(text, "recover", 1, true) ~= nil
                if b.castByPlayer then mineNexus, mineHeal = true, heal end
                if heal then anyHeal = true end
            end
        end
    end
    local tactic = (GameData.Player.career.id == RUNE_PRIEST) and "tacticRP" or "tacticZ"
    local sym
    if mineRitual then sym = mineRitual
    elseif mineNexus then sym = mineHeal and baseKey or tactic
    else sym = tacticAtCreation and tactic or baseKey end
    local cir
    if mineRitual then cir = mineRitual
    elseif anyRitual then cir = anyRitual
    elseif mineNexus then cir = anyHeal and baseKey or tactic
    else cir = sym end
    return sym, cir
end

local function hideNexus()
    active = false
    if attachedObj then
        DetachWindowFromWorldObject(NEXUS, attachedObj)
        attachedObj = nil
    end
    WindowSetShowing(NEXUS, false)
    WindowSetAlpha(CIRCLE, 0)
    symKey, cirKey = nil, nil
end

local function applyNexusVisibility()
    if not active then return end
    WindowSetAlpha(NEXUS, S.symbol and 1 or 0)
    WindowSetAlpha(CIRCLE, S.pointer and 1 or 0)
end

function R.RefreshNexus()
    if not nexusOn then return end
    local pet = GameData.Player.Pet
    local obj = pet and pet.objNum or 0
    local name = pet and pet.name
    if obj == 0 or name == nil or name == L"" then hideNexus() return end
    if attachedObj ~= obj then
        if attachedObj then DetachWindowFromWorldObject(NEXUS, attachedObj) end
        tacticAtCreation = dpsTacticEquipped()
        MoveWindowToWorldObject(NEXUS, obj, 1)
        AttachWindowToWorldObject(NEXUS, obj)
        attachedObj = obj
    end
    WindowSetShowing(NEXUS, true)
    active = true
    applyNexusVisibility()
    setColors(currentKeys())
end

function R.OnEffects()
    if active then setColors(currentKeys()) end
end

-- Direction du cercle : aucune action sans Nexus ni pointer
function R.OnUpdate(dt)
    if not active or not S.pointer then return end
    acc = acc + dt
    if acc < INTERVAL then return end
    acc = 0
    local nx, ny = WindowGetScreenPosition(NEXUS)
    if nx + ny == 0 then return end
    local sx, sy = WindowGetScreenPosition(CIRCLE)
    local ax = WindowGetScreenPosition(SCALE)
    local k = 1
    if ax and ax > 0 then k = (SystemData.screenResolution.x / 2) / ax end
    local dx = (nx + HALF / k) - (sx + HALF / k)
    local dy = (ny + HALF / k) - (sy + HALF / k)
    DynamicImageSetRotation(CIRCLE_ICON, math.atan2(dy, dx) / (math.pi / 180) - 90)
end

-- =============================================================== configuration
local function applyCareerTextures()
    local rp = (GameData.Player.career.id == RUNE_PRIEST)
    baseKey = rp and "rpbase" or "base"
    local ss = (S.sizeSymbol > 0) and S.sizeSymbol or DEFAULT_SIZE
    local sc = (S.sizePointer > 0) and S.sizePointer or DEFAULT_SIZE
    DynamicImageSetTexture(NEXUS_ICON, rp and "RM_RPSymbol" or "RM_Symbol", 0, 0)
    DynamicImageSetTextureDimensions(NEXUS_ICON, ss, ss)
    DynamicImageSetTexture(CIRCLE_ICON, rp and "RM_RPPointer" or "RM_Pointer", 0, 0)
    DynamicImageSetTextureDimensions(CIRCLE_ICON, sc, sc)
end

-- Remet les deux fenetres a leur place et a leur taille d'origine
local function resetLayout()
    local scale = 1
    if InterfaceCore and InterfaceCore.GetScale then scale = InterfaceCore.GetScale() end
    WindowClearAnchors(STATE)
    WindowAddAnchor(STATE, "center", "Root", "center", 0, -150)
    WindowSetDimensions(STATE, 64, 64)
    WindowSetScale(STATE, scale)
    WindowClearAnchors(CIRCLE)
    WindowAddAnchor(CIRCLE, "center", "Root", "center", 0, -60)
    WindowSetDimensions(CIRCLE, 64, 64)
    WindowSetScale(CIRCLE, scale)
end

-- Active ou coupe chaque groupe d'evenements selon les reglages
function R.ApplyConfig()
    local wantLoaded = S.on
    local wantHarb = S.on and (S.dps or S.heal)
    local wantNexus = S.on and (S.pointer or S.symbol)

    if wantLoaded ~= loadedOn then loadedOn = wantLoaded registerGroup(LOADED_EVENTS, wantLoaded) end
    if wantHarb ~= harbOn then harbOn = wantHarb registerGroup(HARBINGER_EVENTS, wantHarb) end
    if wantNexus ~= nexusOn then nexusOn = wantNexus registerGroup(NEXUS_EVENTS, wantNexus) end

    if wantHarb then harbingerLoaded() else drawState() end
    if wantNexus then
        symKey, cirKey = nil, nil
        R.RefreshNexus()
    else
        hideNexus()
    end
end

function R.OnLoaded()
    if not S then return end
    if harbOn then harbingerLoaded() end
    if nexusOn then R.RefreshNexus() end
end

function R.OnReload()
    if R.savedState == "DPS" or R.savedState == "HEAL" then R.state = R.savedState end
    R.OnLoaded()
end

-- =============================================================== commandes
local function onoff(b) return b and "ON" or "OFF" end

local function status()
    say("Ritual Master : " .. onoff(S.on) .. " | dps " .. onoff(S.dps) .. " | heal " .. onoff(S.heal)
        .. " | pointer " .. onoff(S.pointer) .. " | colors " .. onoff(S.colors) .. " | symbol " .. onoff(S.symbol), 143)
end

local function sizeStatus()
    local function v(n) return (n > 0) and n or DEFAULT_SIZE end
    say("Ritual Master : size pointer " .. v(S.sizePointer) .. " | symbol " .. v(S.sizeSymbol)
        .. " | dps " .. v(S.sizeDps) .. " | heal " .. v(S.sizeHeal), 151)
end

local SIZE_FIELDS = { pointer = "sizePointer", symbol = "sizeSymbol", dps = "sizeDps", heal = "sizeHeal" }
local USAGE = "/rm on | /rm off | /rm reset | /rm dps | /rm heal | /rm pointer | /rm symbol | /rm colors | /rm size pointer 0 | /rm size symbol 0 | /rm size dps 0 | /rm size heal 0"

function R.Slash(args)
    local text = string.lower(tostring(args or ""))
    local cmd, kind, value = string.match(text, "^%s*(%a*)%s*(%a*)%s*(%d*)")
    local isSize = false
    if cmd == "on" then
        for k, v in pairs(DEFAULTS) do if type(v) == "boolean" then S[k] = v end end
    elseif cmd == "off" then
        S.on = false
    elseif cmd == "dps" or cmd == "heal" or cmd == "pointer" or cmd == "colors" or cmd == "symbol" then
        S[cmd] = not S[cmd]
    elseif cmd == "reset" then
        for k, v in pairs(DEFAULTS) do S[k] = v end
        resetLayout()
        applyCareerTextures()
        drawnTex = nil
    elseif cmd == "size" and SIZE_FIELDS[kind] and value ~= "" then
        S[SIZE_FIELDS[kind]] = tonumber(value) or 0
        applyCareerTextures()
        drawnTex = nil
        isSize = true
    elseif cmd == "" then          -- /rm ou /ritualmaster seul : etat puis liste des commandes
        status()
        say(USAGE, 149)
        sizeStatus()
        return
    elseif cmd == "size" and kind == "" then
        sizeStatus()
        return
    else
        say(USAGE, 149)
        return
    end
    R.ApplyConfig()
    applyNexusVisibility()
    if isSize then sizeStatus() else status() end
end

function R.Initialize()
    if RitualMaster.Settings == nil then RitualMaster.Settings = {} end
    S = RitualMaster.Settings
    for k, v in pairs(DEFAULTS) do
        if S[k] == nil then S[k] = v end
    end
    R.textures = HARBINGER_TEX[GameData.Player.career.id]
    if not R.textures then return end

    CreateWindow(SCALE, true)
    WindowClearAnchors(SCALE)
    WindowAddAnchor(SCALE, "topleft", "Root", "topleft", SystemData.screenResolution.x / 2, SystemData.screenResolution.y / 2)
    CreateWindow(STATE, false)
    CreateWindow(NEXUS, false)
    CreateWindow(CIRCLE, true)
    WindowSetAlpha(CIRCLE, 0)
    applyCareerTextures()

    if LayoutEditor and LayoutEditor.RegisterWindow then
        LayoutEditor.RegisterWindow(STATE, L"Ritual Master - Harbinger", L"Etat de Harbinger", true, true, true, nil)
        LayoutEditor.RegisterWindow(CIRCLE, L"Ritual Master - Pointer", L"Direction du Ritual Nexus", false, false, true, nil)
    end
    if LibSlash and LibSlash.RegisterSlashCmd then
        LibSlash.RegisterSlashCmd("rm", R.Slash)
        LibSlash.RegisterSlashCmd("ritualmaster", R.Slash)
    end
    R.ApplyConfig()
end
