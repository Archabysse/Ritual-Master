<?xml version="1.0" encoding="UTF-8"?>
<ModuleFile xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <UiMod name="RitualMaster" version="1.5" date="16/11/2026">
        <VersionSettings gameVersion="1.4.8" windowsVersion="1.0" savedVariablesVersion="1.0" />
        <Author name="Abyss" />
        <WARInfo>
            <Careers>
                <Career name="ZEALOT" />
                <Career name="RUNE_PRIEST" />
            </Careers>
        </WARInfo>
        <Description text="Ritual Master : indicateur Harbinger (DPS / soin) + marque, direction et couleur du Ritual Nexus. /rm" />
        <Dependencies>
            <Dependency name="EATemplate_DefaultWindowSkin" />
            <Dependency name="EASystem_Utils" />
            <Dependency name="EASystem_WindowUtils" />
            <Dependency name="EA_ActionBars" />
            <Dependency name="LibSlash" />
        </Dependencies>
        <Files>
            <File name="RitualMaster.lua" />
            <File name="RitualMaster.xml" />
            <File name="zealot_dps.tga" />
            <File name="zealot_heal.tga" />
            <File name="runepriest_dps.tga" />
            <File name="runepriest_heal.tga" />
            <File name="symbol.tga" />
            <File name="pointer.tga" />
            <File name="rp_symbol.tga" />
            <File name="rp_pointer.tga" />
        </Files>
        <SavedVariables>
            <SavedVariable name="RitualMaster.Settings" global="false" />
            <SavedVariable name="RitualMaster.savedState" global="false" />
        </SavedVariables>
        <OnInitialize>
            <CallFunction name="RitualMaster.Initialize" />
        </OnInitialize>
        <OnUpdate>
            <CallFunction name="RitualMaster.OnUpdate" />
        </OnUpdate>
    </UiMod>
</ModuleFile>
